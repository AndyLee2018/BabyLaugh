!(function() {
  var e = "111000";
  try {
    !(function(t) {
      window._SF_ &&
        window._SF_._global_ &&
        window._SF_._global_._ssp &&
        (t = window._SF_._global_._ssp);
      var a = "___delivery___global___counter___";
      try {
        top.location;
        t.counter = top[a] = top[a] || {};
      } catch (n) {
        t.counter = window[a] = window[a] || {};
      }
      var i = "pkchsjlgc",
        o = i,
        r = document.getElementById(o);
      r ||
        ((o =
          "_" +
          Math.random()
            .toString(36)
            .slice(2)),
        ((r = document.createElement("div")),
        (r.id = o),
        (r.style.width = "100%"),
        document
          .getElementsByClassName("_paradigm_S27_csdn_ads_render")[0]
          .insertBefore(
            r,
            document.getElementById("_paradigm_S27_csdn_ads_script")
          )));
      var d = {
        id: "u3596743",
        container: o,
        painterType: "1",
        mixOffset: parseInt("1434", 10),
        gldiOffset: parseInt("4", 10),
        mixType: 2,
        proxy: parseInt("-1", 10),
        exps: "",
        adInfo: new Function(
          'return {"tuid":"u3596743","painter":1,"platformType":"union","placement":{"basic":{"flowType":1,"userId":1574361,"cname":"csdnbaidu_cpr","sspId":1,"conBackEnv":1,"rspFormat":1,"sellType":2,"mediumType":1,"tuId":9223372032563405000,"publisherDomain":{"dup":"rabc1.iteye.com","ubmc":"rabc2.iteye.com/i","pos":"rabc2.iteye.com","wn":"rabc2.iteye.com/qqe"}},"container":{"anchoredType":1,"floated":{},"width":300,"height":250,"sizeType":1}},"update":1545438652000,"mixOffset":1434}'
        )()
      };
      "undefined" != typeof e && e && (d.exps = e), (t.api = t.api || []);
      var p = null,
        c = "u3596743";
      if (
        (window["_" + i]
          ? (p = window["_" + i])
          : window["_" + c] && (p = window["_" + c]),
        p)
      ) {
        var s;
        if (p instanceof Array) {
          var _ = p.shift();
          _ && _.container && (d.container = _.container),
            (d.apiInfo = _),
            (s = _.exps);
        } else (d.apiInfo = p), (s = p.exps);
        s && (d.exps ? (d.exps += "," + s) : (d.exps = s));
      }
      var l = 1e4 * Math.random();
      l >= 1e3 && 2e3 > l
        ? (d.exps = d.exps ? d.exps + ",113000" : "113000")
        : l >= 2e3 &&
          3e3 > l &&
          (d.exps = d.exps ? d.exps + ",114011" : "114011"),
        setTimeout(function() {
          t.api.push(d);
        }, 1);
      var w = "irlptqpn";
      if (!t[w]) {
        t[w] = !0;
        var m = document.createElement("script");
        (m.type = "text/javascript"),
          (m.async = !0),
          (m.src =
            ("https:" === document.location.protocol ? "https:" : "http:") +
            "//rabc1.iteye.com/rlptqpn.js");
        var u = document.getElementsByTagName("script")[0];
        u.parentNode.insertBefore(m, u);
      }
    })((window.__delivery_global_ = window.__delivery_global_ || {}));
  } catch (t) {
    var a = t && t.stack ? t.stack : t;
    new Image().src =
      "//eclick.baidu.com/se.jpg?type=delivery&date=1219&mes=" +
      encodeURIComponent(a);
  }
})();
